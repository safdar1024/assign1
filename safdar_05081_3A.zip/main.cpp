#include <cstdlib>
#include <iostream>
#include<cstring>
#include "StringBuffer.h"
#include "String.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

//1. using Owned Pointer

class owned_smart_pointer{

private:
	bool shared;
        char* pointr_buffr;                                   
        int lngth; 

public :
    owned_smart_pointer(char* str,int len)
{
    pointr_buffr = str;
    lngth = len;
}

    owned_smart_pointer(char* ch = 0) throw(): shared(ch!=0), pointr_buffr(ch) {}

void reserve_pointer(int position)
{
	pointr_buffr = new char[position];
}

   
    int smart_str_len() const{
	return lngth;
}


char charposition(int position) const
{
	return pointr_buffr[position];
}



void append_char(char ltr)
{
	pointr_buffr[lngth] = ltr;
	lngth += 1;
}
                   
    ~owned_smart_pointer()  
{
	if (shared)
	{
		delete[] pointr_buffr;
	}
	delete pointr_buffr;
	
}

 


    owned_smart_pointer& operator =(const owned_smart_pointer &MyVar )
    { 

    	if (&MyVar != this) {
            if (pointr_buffr != MyVar.pointr_buffr)
            {
                if (shared)
                {
                	delete[] pointr_buffr;
                	delete pointr_buffr;
                }
                shared = MyVar.shared;
            }
            else if (MyVar.shared) shared = true;
            delete[] pointr_buffr;
            pointr_buffr = MyVar.del_pointers();

            lngth = MyVar.lngth;
        }

        return *this;
    }

     
     owned_smart_pointer(const owned_smart_pointer& MyVar) throw(): shared(MyVar.shared), pointr_buffr(MyVar.del_pointers()) 
	{
	}

 char* del_pointers()  const throw()
    {
    	(const_cast<owned_smart_pointer* >(this))->shared = false; 
    	return pointr_buffr;
    }

};

//2. copied Pointer:

class copy_str{

private:
    char* Strbuffer;                                   
    int lngth;                                       

public :

copy_str(const copy_str& MyVar)
{
    Strbuffer = new char [MyVar.lngth];
    strcpy(Strbuffer, MyVar.Strbuffer);
    lngth = MyVar.lngth;       
}


copy_str(char* str,int len)
{
    Strbuffer = str;
    lngth = len;
}
int smart_str_len() const{
	return lngth;
}


char charposition(int position) const
{
	return Strbuffer[position];
}


void reserve_pointer(int position)
{
	Strbuffer = new char[position];
}

void append_char(char letter)
{
	Strbuffer[lngth] = letter;
	lngth += 1;
}

     copy_str(char* ch = 0) throw()     : Strbuffer(ch) 
     {
        lngth = 0;
     }


copy_str& operator= (const copy_str &MyVar )
    { 
        if (this != &MyVar)
        {
            delete[] Strbuffer;
            Strbuffer = new char [MyVar.lngth];
            strcpy(Strbuffer, MyVar.Strbuffer);
            lngth = MyVar.lngth;       
        }
        return *this;
    }

~copy_str()  
{

    delete[] Strbuffer;
   
}
};

//3. COW link Reference:
class Ref_str{

private:
                                     
    char*    pointr_buffr; 
    int len;
    
    Ref_str*   pre_pointer;
    Ref_str*   NexPtr;
    
    void bring(const Ref_str& Myvar) throw()
    { // insert this to the list
        pointr_buffr = Myvar.pointr_buffr;
        len = Myvar.len;
        NexPtr = Myvar.NexPtr;
        NexPtr->pre_pointer = this;
        //*pre_pointer = Myvar;
        (const_cast<Ref_str*>(&Myvar))->NexPtr = this;
    }

public :
    
int smart_str_len() const{
	return len;
}


char charposition(int position) const
{
	return pointr_buffr[position];
}


void reserve_pointer(int position)
{
	pointr_buffr = new char[position];
}

    char* get_ptr() const throw()   {return pointr_buffr;}
    

	Ref_str(const Ref_str& Myvar)
	{
        bring(Myvar);
        len = Myvar.len;
        
	}

void append_char(char letter)
{
	if(diff())
	{
		
		pointr_buffr[len] = letter;
		len += 1;
	}
	else
	{
		char* tmp = new char[len];
		strncpy(tmp,pointr_buffr,len);
		rel();
		pointr_buffr = new char[len];
		strncpy(pointr_buffr,tmp,len);
		pointr_buffr[len] = letter;
		len += 1;
		delete[] tmp;
		NexPtr = pre_pointer = this;

	}
	
}
    

Ref_str(Ref_str* p = 0) throw()   : pointr_buffr(0) 
    {
        pre_pointer = NexPtr = this;
    }


       Ref_str& operator= (const Ref_str &Myvar )
    { 

    	if (this != &Myvar) {
            rel();
            bring(Myvar);
        }
        return *this;
    }

    bool diff()   const throw()  
     {
     	if(pre_pointer == this && NexPtr == this)
     		return 1;
     	else
     		return 0;
     }

 void rel()
    { // erase this from the list, delete if diff
        if (diff()) 
        	delete[] pointr_buffr;
        else
        {
            pre_pointer->NexPtr = NexPtr;
            NexPtr->pre_pointer = pre_pointer;
            pre_pointer = NexPtr = 0;
            //delete[] pointr_buffr;
        }
       
    }

  ~Ref_str()  
{
       rel();

}

   };

int main(int argc, char** argv) {
    
//owned Pointer 
        cout<<"owned Pointer!" <<endl;
	owned_smart_pointer* pointer_obj = new owned_smart_pointer();
	pointer_obj->reserve_pointer(12);
	pointer_obj->append_char('d');
        pointer_obj->append_char('e');
	pointer_obj->append_char('f');
	cout<<"pointer_obj smart_str_len = "<<pointer_obj->smart_str_len()<<std::endl;

	owned_smart_pointer* pointer_obj1 = new owned_smart_pointer(*pointer_obj);
	pointer_obj1->reserve_pointer(12);
	*pointer_obj1 = *pointer_obj;
         int check =0;
	cout<<"pointer_obj1 smart_str_len = "<<pointer_obj1->smart_str_len()<<std::endl;
     //test
int i=0; 
      while(i<3){
	
	
		if(pointer_obj->charposition(i) != pointer_obj1->charposition(i))
		{
			cout<<"owned pointer not successfull!"<<endl;
			check = 1;
		}
	
        i++;
}
	if(check!=1)
		cout <<"Owned Pointer Test Successful!!!"<<endl;
	
   //Copied Pointer
  check = 0; 
 	cout<<"\n\nCopied Pointer!" <<endl;

       copy_str pointer_obj2;
	pointer_obj2.reserve_pointer(12);
	pointer_obj2.append_char('d');
	pointer_obj2.append_char('e');
        pointer_obj2.append_char('f');
         
        cout<<"pointer_obj2 smart_str_len = "<<pointer_obj2.smart_str_len()<<std::endl;
	
       copy_str pointer_obj3(pointer_obj2);
cout<<"pointer_obj3 smart_str_len = "<<pointer_obj3.smart_str_len()<<endl;
	i=0;

//test
while(i<3){
	{
		if(pointer_obj2.charposition(i) != pointer_obj3.charposition(i))
		{
			cout<<"copied pointer not successfull!"<<endl;
			check = 1;
		}
	}
   i++;
}
if(check!=1)
cout <<"copied Pointer Test Successful!!!"<<endl;



     cout<<"\n\nCOW with reference count!"<<endl;

    //COW with reference count
    char* reference = "reference";
    String newStr2(reference,9);
    cout<<"newStr2 smart_str_len = "<<newStr2.length()<<std::endl;
    cout<<reference<<endl;
    String newStr(newStr2);
    cout<<reference<<endl;
    cout<<"newStr smart_str_len = "<<newStr.length()<<endl;
    cout<<"new newStr charposition 0 = "<<newStr.charAt(0)<<endl;
    newStr2.append('l');
    cout<<"new newStr smart_str_len = "<<newStr.length()<<endl;
    cout<<"new newStr2 smart_str_len = "<<newStr2.length()<<endl;
    
//COW linking

cout<<"\n\nCOW linking!" <<endl;
check = 0;
       Ref_str* pointer_obj4 = new Ref_str();
	pointer_obj4->reserve_pointer(12);
	pointer_obj4->append_char('d');
	pointer_obj4->append_char('e');
	cout<<"pointer_obj4 smart_str_len = "<<pointer_obj4->smart_str_len()<<endl;
	pointer_obj4->append_char('f');        
cout<<"pointer_obj4 smart_str_len = "<<pointer_obj4->smart_str_len()<<endl;

	Ref_str* pointer_obj5 = new Ref_str();
	pointer_obj5->reserve_pointer(12);
	*pointer_obj4 = *pointer_obj5;
if(check!=1)
cout<<"pointer_obj5 smart_str_len = "<<pointer_obj5->smart_str_len()<<endl;

i=0;

//test

while(i<3){

	{
		if(pointer_obj4->charposition(i) != pointer_obj5->charposition(i))
		{
	                cout<<"COW linking Test not successfull!"<<endl;
			check = 1;
		}
	}

i++;
}		
if(check!=1)
cout <<"COW linking Test Successful!!!"<<endl;


    return 0;
}
